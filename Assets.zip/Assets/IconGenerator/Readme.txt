Hello, thank you for downloading my asset! If you like it, please consider rating it on the asset store!
If you have any questions / problems, please contact me at: rockis167@gmail.com

-MrRockis


FAQ:
Q: How to use this asset?
A: Please check HowToUse.txt !

Q: How does the "File Names" array work?
A: If you want to use custom file names, you can specify a name for each of your prefabs there. 
	Please make sure your "indexes" match. For example if your prefab is in the slot "Element 1", it will take the name from File Name's "Element 1" slot!

Q: I get `string' does not contain a definition for `IsNullOrWhiteSpace' -error.
A: This error should have been fixed in the 2.1 update. If you are still getting this, please contact me!
A: You are currently using Unity's deprecated .NET 3.5 Equivalent. Please update to using the new .NET 4.x Equivalent in Player Settings -> Other Settings -> Scripting Runtime Version

Q: No icons were generated...
A: Did you run the scene? Please check the console for more information! Also currently unity has a bug that you need to click outside the editor window, for the icons to be refreshed.

Q: How does the overlays stack?
A: Please check HowToUse.txt! Higher index = on top.

Q: I don't like to use your example scene. Can I use my own?
A: YES! Of course you can. Please remove all lines commented with // from the IconGenerator.cs file to avoid errors.

A: Is it fully free?
Q: YES!